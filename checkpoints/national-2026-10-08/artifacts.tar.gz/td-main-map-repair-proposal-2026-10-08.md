# Main-map repair proposal — approval required

Status: proposal only. Owner says presentation deadline has passed; prioritize the shortest checked repair path, not a new nationwide pipeline. No repair code, solver jobs, geometry gates, new maps or source edits have started. Existing measurement-only authorization does not authorize this implementation.

## Preserve the baseline

Primary comparison/repair seed: `ne_plains_wh11_fi20_finonc_whnonj` — NE + plains combined, WH 11 (national 15 / WH 11 / FI 20 / combined 3), smallest-δ plan, FI without NC, WH without NJ, 12 splits. Image: `runs/exp/contig/set125/fi20_fi_nonc_wh_nonj-r1/summary.png`. Cached 12 splits / 19 cuts / 4 defects.

Alternative: `ne_plains_wh11_fi20_whnonj` — same K/layout, smallest-δ plan, WH without NJ split, 12 splits. Image: `runs/exp/contig/set125/fi20_wh_nonj-r1/summary.png`. Cached 12 splits / 20 cuts / 2 defects. Owner may prefer this on looks; neither is eligible under current dollars.

Keep both original folders and renders immutable. Preserve FI and WIFI ownership: each passes current dollar checks. No fresh M1 or shape approval is implied. Fixed total K49 first; changing K requires a separate owner decision.

## Verified targets

Both seeds have identical failures, no over-band districts:

| District | Drawn $M, approximate | Deficit to lower edge $M |
|---|---:|---:|
| national_01 | 1,014.085 | 48.415 |
| national_09 | 1,022.841 | 39.659 |
| WH_09 | 840.770 | 9.230 |

National target window: $1,062.5M–$1,437.5M. WH: $850M–$1,150M. Use unrounded E1 fine-rate dollars. Authoritative audit: `td-main-map-dollar-audit-2026-10-08-v2.{json,csv}` in this drafts directory.

## Pilot A: national, K15 retained

- First authorized region: national_01 + national_09 + national_12. Freeze every other national district and all other channels.
- Required funding: about $88.074M into the two deficient districts. national_12 has about $130.201M above its floor, but this is arithmetic capacity only.
- Screen whole-state regrouping first. Hold non-FL states whole; preserve existing permitted split/cut/support/shape limits. Then solve only the needed Florida ownership change with exact per-ZIP fine-dollar coefficients and connectivity.
- Do not attempt the superficial TN↔SC swap: TN in national_12 is only about $76.529M, versus SC in national_01 about $161.936M. It moves funding in the wrong direction. A two-district Florida exchange alone also cannot fund both shortages.
- No speculative hand-picked replacement support is declared feasible. Whole-state adjacency, support limits, dollar capacity and current M1 must all pass.
- If the three-district region is proved infeasible, return that scoped result. Optional expansion to national_02 requires explicit approval; it contributes only about $25.640M floor slack and does not solve both deficits alone. No silent expansion or K change. A timeout proves nothing global.

## Pilot B: WH, K11 retained

- Authorized candidate region, if approved: WH_08 + WH_09 + WH_11. Twelve whole states: IA IL MN MO / IN KY MI WI / OH TN VA WV. Freeze all other WH ownership and all other channels.
- Regroup these states into three whole-state districts under the full $850M–$1,150M window. WH_08 has about $51.208M floor slack and WH_11 about $42.705M; WH_09 lacks $9.230M. Arithmetic slack is not a connected plan.
- Retain existing support/diameter/shape caps. No partial-state donation or new split as a shortcut. Each proposed whole-state support must pass current M1 before full-map assembly.
- If no admissible regroup is proved, report the restriction and stop; do not quietly loosen the state-piece contract or widen the band.

## Smallest implementation needed — not yet authorized

Existing repair.py triggers detached pieces and necks, not dollar-only violations. Its --window is an m_rel intersection, not a general D3 dollar adapter. Rerunning it unchanged is not a repair plan.

Reuse existing planners/window MILP and E1 pricing. Add only the explicit dollar-rebalance trigger and fixed-target dollar rows needed by these pilots. National coefficients must sum its fine-channel dollar values per ZIP; WH's one fine-channel rate admits a scalar conversion. Use the full owner window, not a hidden narrower legacy τ-band intersection. Preserve raw opportunity/ledger semantics; do not reinterpret m_rel or patch the global scorer/deck pipeline.

Before code changes: refresh/pin the approved branch against current main and consult research about shared run.py/repair.py/merge.py interfaces. Work only in our separate worktree. Do not touch lander-owned main, issue queue, shortlist, STATE.md, mandates or problem docs. No prototype IFA flag for main verdicts; use the current landed M1 rule.

## Acceptance and stop rule

A repaired result needs unchanged non-target cells and complete audited ZIP/fine ownership, all four channels' current dollar checks, M1, rule C, existing split/cut caps and owner visual acceptance. Do not claim global split minimality. Solver claims use the engine's real stop reason and the existing certificate settings; unknown is never infeasible or pass.

Write new run folders through the approved run/repair entry points with manifests. Never overwrite originals. Render only new results after checks; lander registers each shown map under T1. No blanket shortlist/deck refresh and no re-render of the 58 accepted maps.

## Approval needed before any implementation

1. Which pilot(s): national, WH, or both; and which seed if owner overrides the saved cuts-first order.
2. Source-edit/repair/gate authorization. Confirm restricted regions above, no automatic expansion, no K/band/split-cap change.
3. Main solver allocation within the machine-wide cap, coordinated with IFA. Current allocation remains zero. A single serial slot is the smallest proposed allocation, not an assumed grant.
4. An explicit bounded engineering/solve budget and stop condition. Urgency is not permission for unbounded work or weaker checks.

While unapproved, only this proposal and the existing measured progress evidence are deliverables. If neither pilot is justified, retain both current maps as clearly labelled progress-only dollar failures; do not call them final or eligible.

LEARNED: TN↔SC alone cannot fund the national repair: existing national_12 TN is about $76.529M and national_01 SC about $161.936M.
DECIDED: Propose fixed-K restricted pilots first; global replan is not supported as the shortest checked path, and no implementation is authorized.
