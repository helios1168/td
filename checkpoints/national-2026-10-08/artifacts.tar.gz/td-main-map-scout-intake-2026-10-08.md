# Main-map scout intake — 2026-10-08 05:40 CDT

## Post-dispatch correction — main 1293d41, 05:56 CDT

WIFI IS the combined channel; E3's ±15% global dollar-mean band applies. The lander's c989cbf exemption was an error and has been reverted in PROBLEM.md and WATCHDOG.md. The historical intake below and frozen scout reports include the now-superseded exemption; do not use that statement as current policy. Original launch evidence is retained for audit.

## Historical launch intake

Owner authorized eight READ-ONLY scouts, explicitly no code execution. Routing: five openai-codex/gpt-6.1-sol:high and three claude-bridge/claude-sonnet-5-5:medium. Target first synthesis within ten minutes of dispatch. No main solver slots allocated.

## Snapshot and authority

Repo hub: /Users/Shared/sv-ntlee/td
Dedicated scout cwd: /Users/sandvault-ntlee/.pi/worktrees/national-scouts-2026-10-08
Branch: m5-studio/national-scouts-2026-10-08
HEAD: f11faed228f4df20afb41421011b164265178e18
Parents: explore-neck d312834f9b0acfdb4485c0e021402086b9645e1e plus origin/main ff4cb668f496cc9229de363d5ef57b52a9b7166d.
Git-only setup performed; hooks disabled for setup so no project code ran. Scout worktree and hub were clean after setup. No project source changes, tests, gates, renders or solvers executed by national session.

Read committed source from scout cwd. Existing ignored run artifacts/caches live at the hub; cite their paths and observed freshness separately from source HEAD. Some regional artifacts also live in research/IFA worktrees. Never write in another checkout.

Owner goal: stakeholder PROGRESS REVIEW, PDF + PNG, main channels national/WH/FI/WIFI-or-combined. Bounded repair proposals only; no repair execution. Three-hour window counted from original request around 04:45 CDT, not from scout launch.

## Peer handoff facts (reported; inspect source where possible)

Contiguity and research agreed explore-neck + latest main is appropriate. run.py --states and repair.py --states --window are paired, self-contained scope tools. merge.py is optional. G1 prototype is default off; never enable TD_NECK_GAP_WIDTH for main-map verdicts while #131 remains unlanded. The main branch still does not implement D3 in tools/looks/score.py; ELIGIBLE flags can be stale.

Current D3: national $1,062.5M–$1,437.5M, WH $850M–$1,150M, FI $765M–$1,035M per district, using fine-channel whole-extract rates. WIFI has a ±15% dollar-mean band; the combined channel remains exempt. Identify bundle semantics from scenarios/ledger, not its display name. Main total K 48–54. Rank splits, cuts, defects, shape, balance. Unknown is never a pass. Do not assert minimal without a bound covering the map.

Research reported lead ne_plains_wh11 D3 compliance national 13/15 (two under at about $1,016M/$1,021M), WH 10/11 (one about $841M), FI 20/20. Earlier lander national low-dollar estimates differ. These are reported measurements, not measurements verified by national session; trace to saved evidence or mark unknown. Do not execute scripts or recompute/publish new measured tables.

The 58 pre-#128 renders are permanently accepted as-is. Never rerender them, ask again or recommend a blanket --deck refresh. Shape quality matters; mass-only slivers are not accepted territories.

Contiguity owns main, shortlist registration, STATE.md and issue/problem records for this handoff. Research coordinates shared experimental tools. #103/#129/#130 are on hold. Do not edit those stores or reopen settled design.

## Candidate anchors (cached, not freshly gated)

- ne_plains_wh11_fi20_whnonj: NE + plains combined, national 15 / WH 11 / FI 20 / combined 3, 12 splits, 20 cuts. Hub run runs/exp/contig/set125/fi20_wh_nonj-r1; summary.png and zip_pages.pdf exist.
- ne_plains_wh11_fi20_finotn_whnonj: same layout/K, FI without TN and WH without NJ, 12 splits, 20 cuts. Hub run runs/exp/contig/set125/fi20_fi_notn_wh_nonj-r1; images exist.
- ne_plains_wh11: earlier lead, same layout/K, 14 splits, 21 cuts. Hub run runs/exp/contig/border/ne_plains_wh11-r2-all; images exist.

Registry is tools/shortlist/shortlist.json in pinned scout checkout; ignored generated view at hub runs/shortlist/INDEX.md; tracker at hub runs/exp/index.jsonl. Cache age/tier are evidence metadata, not current eligibility proof.

## Local live-session snapshot at approximately 05:40 CDT

- national 01a11ae7: hub cwd; parent of this scout wave.
- contiguity 01a109e4: hub cwd; active; lander.
- contiguity-fast 01a10ae2: hub cwd; idle, with older context.
- td-research 01a119b6: explore-td-research cwd; active; head 61363df at Git inventory.
- td-ifa-newengland 01a11af1-06ef: ifa-newengland cwd; idle; head 01ffe5e.
- td-ifa-southatl 01a11af1-0719: ifa-southatl cwd; idle; head 20cfe36.
- td-ifa-midwest 01a11af1-06f7: ifa-midwest cwd; idle; head 8eeb8bf.
- td-ifa-west 01a11af1-073f: ifa-west cwd; idle; head a2d2602.
- td-ifa-southcentral 01a11af1-0732: ifa-southcentral cwd; idle; head a1bfa93.
- worker named subagent: ifa-conus cwd; active tool:bash; exact run ID not present in roster snapshot.

Other local worktrees (activity unknown, not inferred): explore-td-geography 9b28204; explore-td-hypergraph 1d56c62; explore-td-neck d312834; explore-td-nj 9d6f341; explore-td-nycd 2ef5361; explore-td-toy 1d56c62; ifa-midatl 02fffd5; ifa-ny d3b2b92; ifa-conus f172d69; detached /private/tmp/whatif_W1 and W3 at 135a529; six old pi-subagents L1–L6 draft worktrees at 470c18f. All named non-/tmp worktrees live under /Users/sandvault-ntlee/.pi/worktrees/. Idle sessions and old worktrees are not proof of safely reclaimable resources or landable results.

Process inspection at 05:39:56 CDT: Python PIDs 32324 (parent 31707, 103.9% CPU), 32679 (parent 32324, 0%), 33018 (parent 33016, 98.6%), 33022 (parent 33018, 98.9%). Commands were executable names only; arguments/environments intentionally not captured. Do not equate Python process count with solver slots.

Cap: owner selected Raise to 12 in research session, tool-result entry 621c5616, 2026-10-08 09:08:38Z. Research reserves 11 IFA slots plus one assembly slot. Owner selected Scout only for now for main work. No reallocations or solver launches permitted.

## History anchors

Indexed history tools have returned database is locked during parent preparation. If a history tool still fails, note that gap, use available tracked decision/lens/memory evidence, and do not repeatedly retry or dump raw JSONL.

Relevant session identities: research 01a119b6-20a2-718e-b980-a0750bcfb270, contiguity 01a109e4-e8f3-7229-893f-6840ece264af, contiguity-fast 01a10ae2-a0b9-7502-9660-6c7fe067365f. Session files are under /Users/sandvault-ntlee/.pi/agent/sessions/; cross-Studio history may exist under sessions-archive/. Live remote Studio state has not been refreshed; do not claim it current.

Useful source roots: docs/memory/INDEX.md, facts/scenario-sweeps-2026-10.md, decisions/scenario-sweeps-2026-10.md, docs/lenses/REVIEW_2026-10-07.md, docs/lenses/research-2026-10-08/, WATCHDOG.md, docs/problem/PROBLEM.md and MANDATES.md. The research checkout may hold newer decision notes than the pinned neck copy; distinguish sources.
