# Main-map scout findings — progress-review context

2026-10-08. Eight scouts completed: five GPT-6.1 Sol high, three Sonnet 5.5 medium. Dispatch 05:44:45 CDT, completion 05:48:30 CDT: about 3m45s. Source snapshot f11faed228f4df20afb41421011b164265178e18 (explore-neck d312834 + main ff4cb66). Scout worktree and hub were clean at parent inspection 05:49:35. Scouting ran no application code, tests, gates, renders or solvers. The owner subsequently approved measurement-only code; the dollar audit below is complete. No solvers, geometry gates, renders, project source edits or shortlist changes were made. Repairs remain unauthorized; main has no solver allocation.

This readout includes verified dollar arithmetic on the original ledgers, not a full current eligibility certificate. Cached splits/cuts/defects and M1 evidence retain their original meaning. No map is promoted or selected as final.

**Post-dispatch correction, main 1293d41 (05:56 CDT):** WIFI is the combined channel and E3's ±15% global dollar-mean band applies. The lander's c989cbf exemption was an error, now reverted in PROBLEM.md and WATCHDOG.md. This supersedes the exemption/type-splitting claims in the frozen scout reports and earlier messages; those reports remain historical evidence, not current policy.

## First comparison: cuts change the apparent lead

[Registered shortlist at main snapshot](https://github.com/helios1168/td/blob/ff4cb668f496cc9229de363d5ef57b52a9b7166d/tools/shortlist/shortlist.json)

Both candidates: NE + plains combined, national 15 / WH 11 / FI 20 / combined 3, 49 districts.

| Registered candidate | Cached splits | Cached cuts | Cached defect score | Existing summary image |
|---|---:|---:|---:|---|
| `ne_plains_wh11_fi20_finonc_whnonj` — smallest-δ plan, FI without NC, WH without NJ, 12 splits | 12 | 19 | 4 | `runs/exp/contig/set125/fi20_fi_nonc_wh_nonj-r1/summary.png` |
| `ne_plains_wh11_fi20_whnonj` — smallest-δ plan, WH without NJ split, 12 splits | 12 | 20 | 2 | `runs/exp/contig/set125/fi20_wh_nonj-r1/summary.png` |

Both also have registered `zip_pages.pdf` beside their summary image; parent confirmed these files exist and viewed both summary PNGs. The no-NC variant keeps NC whole in FI, but still has involved TN/PA/OH borders. Shape acceptance remains the owner's.

Current `tools/looks/score.py:419–422` ranks splits, defects, shape and balance, omitting cuts. Settled PROBLEM.md:56 puts cuts before defects. Thus cached P1/P3 ordering is not the settled order. Saved metrics favor the no-NC/no-NJ candidate first, unless the owner invokes a visual REVIEW override. The no-TN/no-NJ variant (12/20/3 cached) remains a third alternative, not the first two-map comparison.

Earlier `ne_plains_wh11` — border redraw, 14 splits/21 cuts, image `runs/exp/contig/border/ne_plains_wh11-r2-all/summary.png` — is historical baseline, not a ranking winner among these saved candidates.

## Owner-authorized dollar audit — complete

Existing `dollar_rates` and `dollars_per_district` helpers priced each ledger district with whole-extract E1 fine-channel rates. Both inputs match the original run extract hash, `39e2b475…`; opportunity matches the source cell-by-cell. Each ledger has 166,500 unique cells, 33,300 represented ZIPs, and 49 declared/owned districts. These are ledger counts, not an independent full-vertex/M1 coverage certificate. Every original run file, including renders, was fingerprinted before/after and remained unchanged.

| Channel | In dollar band, both candidates | Failure |
|---|---:|---|
| national | 13/15 | `national_01`, `national_09` below $1,062.5M |
| WH | 10/11 | `WH_09` below $850M |
| FI | 20/20 | none |
| WIFI/combined | 3/3 | none under E3 |

| District, identical dollars in both seeds | Drawn $M | Shortfall $M | States |
|---|---:|---:|---|
| national_01 | ≈1,014.085 | ≈48.415 | AL+FL+GA+MS+SC |
| national_09 | ≈1,022.841 | ≈39.659 | FL |
| WH_09 | ≈840.770 | ≈9.230 | IN+KY+MI+WI |

Comparisons used unrounded dollars, no tolerance. v2 uses integer-percentage arithmetic for the exact nominal FI upper edge; v1's float representation differed by a sub-cent ULP. All district dollars and pass/fail flags stayed unchanged. Boundary self-checks passed. v2 is the authoritative output: `/Users/sandvault-ntlee/drafts/td-main-map-dollar-audit-2026-10-08-v2.{json,csv}`; runnable script is `td-main-map-dollar-audit-2026-10-08.py`. Files remain outside the project checkout.

WIFI's global dollar mean is ≈$1,123.327M, giving ≈$954.828M–$1,291.826M. Its observed range is ≈$1,066.505M–$1,230.693M. FI's minimum is ≈$874.381M for no-NC/no-NJ and ≈$879.548M for no-NJ; both maxima ≈$980.808M.

National deficits sum to ≈$88.074M. `national_12` has ≈$130.201M above its floor; `national_02` only ≈$25.640M. This is arithmetic capacity, not proof of a permissible whole-state transfer or a connected repair. A swap between the two deficient Florida districts alone cannot fund both.

## Current acceptance gaps

1. **Both candidates fail current dollar eligibility.** Three failures are verified above; no over-band district was found. Cached ELIGIBLE remains obsolete.
2. **FI passes D3 dollars in both candidates.** Preserve its existing drawing unless a separate verified defect requires work. This is not a fresh M1/shape pass or an IFA geometry transplant.
3. **WIFI/combined passes E3 dollars in both candidates.** No exemption or ordinary-versus-exempt subtype distinction. Preserve existing drawing unless a separate verified defect requires work; full current eligibility remains unclaimed.
4. **M1 evidence is cached.** Old checks/registries record zero detached pieces/necks/missing owners. They were not re-gated against current source. G1/G3 IFA prototype verdicts do not grant main-map flag use.
5. **Legacy captions need disclosure, not refresh.** Existing summaries say ±10%/within-τ-band and use “reps” in the structure legend. A progress-review caveat sheet must distinguish those legacy labels from current D3 and district-only scope. The 58 accepted old renders remain untouched.

## Iteration is not just rerunning repair.py

Verified `tools/exp/contig/repair.py:680–738`: repair_channel starts with detached pieces, then necks. A connected, neck-clean district with low dollars gets no balance-only repair. `--window` clips existing m_rel constraints; it does not create a D3 repair trigger or a general fine-dollar master adapter.

- National: proposal only — E1 failures and arithmetic slack are now measured. Inspect a fixed-K southeast donor/whole-state regroup plus Florida rebalance pilot if authorized. Outside donor funding is required; geometry, the state-piece contract, support limits and split/cut caps remain constraints. K15 is not proven impossible. K changes remain separate choices.
- WH: all three inspected seeds share WH_09, whole IN+KY+MI+WI, with the same saved light mass. Same-support internal ZIP changes cannot create opportunity already fully owned. Proposal: bounded whole-state regroup screen, then realization only if supported. A new partial-state donation may add a split; do not silently relax ranking/caps.
- FI and combined: preserve existing drawings where supportable. No new solve justified by this reconnaissance alone.

Fast historic neck repairs are not a promise of fast dollar repair. Saved draw/window logs include minute-scale timeouts and unresolved cases.

## Presentation path, still code-free

Compare the two existing registered summaries and channel/ZIP pages. A later PDF package can reuse their existing images/PDFs unchanged plus an explicit caveat/provenance sheet. No PDF assembly command has been executed.

Do not use `tools/shortlist/build.py --deck`, even with a subset registry, on accepted old renders: it can rerender stale entries. Renderer refresh overwrites images. Current hash includes scorer source, so a D3 scorer edit would also invalidate render hashes. No-deck builder also rewrites hub tier copies/INDEX and is unnecessary now.

## Coordination and gaps

- Findings sent to contiguity and research as news; main and shortlist registration remain lander-owned.
- IFA work remains separate; do not duplicate or change its region worktrees or assume IFA ledgers can serve main fine channels.
- Cap12 is fully reserved by IFA plan (11 regional, one assembly); main solver allocation is still zero even when processes look idle.
- History indexing was unavailable. Serena overview failed because the configured Serena Python was absent. Narrow source reading and tracked decision evidence were used; no tooling install/restart attempted.
- Default source/scorer mismatches remain deferred work; no issues, source files, mandates or ranking code edited.

## Hold point

Context gathering is complete. No next execution phase starts automatically. E1 dollar checks are complete. Before repair: explicit code/source-edit authorization, owner solver allocation, narrow approved scope and acceptance. Before outward presentation: owner chooses candidate comparison/visual override and sees the cached-versus-current caveats.

Reports: `/Users/sandvault-ntlee/.pi/agent/sessions/--Users-Shared-sv-ntlee-td--/subagent-artifacts/outputs/73bad6a7-d6cb-4463-b3e5-946206535a98/scouts/`.

LEARNED: At f11faed, tools/looks/score.py::rank_key omits cuts although the settled ranking places cuts before defects.
LEARNED: At f11faed, repair.py::repair_channel triggers only piece/neck repairs; --window alone does not repair dollar-only violations in M1-clean seeds.
LEARNED: Main 1293d41 corrects c989cbf: WIFI is the combined channel and E3 applies at ±15% of its global dollar mean; earlier exemption/type-distinction claims are superseded.
LEARNED: Dollar-only audit of ne_plains_wh11_fi20_finonc_whnonj and ne_plains_wh11_fi20_whnonj verifies identical three failures (national_01, national_09, WH_09), with national 13/15, WH 10/11, FI 20/20 and WIFI 3/3 in current dollar bands; original inputs/renders unchanged, no fresh M1/shape certificate.
DECIDED: Keep the saved no-NC/no-NJ and no-NJ variants as the first comparison, not promote either; cached scorer order omits the settled cuts criterion.
