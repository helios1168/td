# Main-map scout plan — stakeholder progress review

Date: 2026-10-08
Session: national
Status: read-only scout wave launched with owner approval, run `73bad6a7-d6cb-4463-b3e5-946206535a98`. Project code execution, repairs, gates, renders and solver runs remain unauthorized.

## Owner choices

- Meeting purpose: progress review, not final-map approval.
- Focus: national, WH, FI, and the WIFI/combined channel structure. IFA work remains with research and its region sessions.
- Deliverables: PDF + PNG, with a concise comparison and caveat sheet.
- Follow-on approach: bounded repairs, after scouting and separate execution approval.
- Work happens in separate worktrees; hub checkout and research worktrees stay untouched.
- Compute decision: scout only for now. No main-map solver slots allocated.
- Presentation window: three hours from the original request; the clock does not reset at launch.

## Base confirmed with contiguity and research

Both sessions now recommend:

1. Start our separate worktree from `m5-studio/explore-neck` at `d312834f9b0acfdb4485c0e021402086b9645e1e`.
2. Merge latest `origin/main` inside that worktree. At setup, main was `ff4cb668f496cc9229de363d5ef57b52a9b7166d`.
3. Scout source is now pinned to `f11faed228f4df20afb41421011b164265178e18`, branch `m5-studio/national-scouts-2026-10-08`, worktree `/Users/sandvault-ntlee/.pi/worktrees/national-scouts-2026-10-08`.

Git-only setup completed cleanly with hooks disabled. Hub checkout stayed untouched; no project code ran.

Useful tools on explore-neck:

- `tools/exp/contig/run.py --states`: state-induced planning/drawing, full-graph audit.
- `tools/exp/contig/repair.py --states --window LO,HI`: scoped piece/neck repairs, with a fixed m_rel window intersected with the scenario band. Depends on the new `run.induced_graph`, so the files belong together.
- `tools/exp/contig/merge.py`: optional regional assembly followed by a full-graph audit. Do not assume its IFA-oriented assembly contract covers arbitrary main-channel assembly; inspect before reuse.
- G1 prototype in `td/audit.py`: default off. Do not set `TD_NECK_GAP_WIDTH=1` for main-map verdicts while #131 remains unlanded.

Alternative, if integration evidence invalidates this base: current main plus the paired run/repair changes and their focused test. Do not switch silently.

## Current contract and traps

- D3: every national district within $1,062.5M–$1,437.5M; WH within $850M–$1,150M; FI within $765M–$1,035M.
- E1: dollar rates come from each fine channel's whole extract; off-map dollars are not credited.
- WIFI is the combined channel and E3 applies: each district within ±15% of the global dollar mean, using whole-extract fine-channel rates. Main 1293d41 corrects the lander's c989cbf exemption; no ordinary-versus-exempt subtype distinction.
- Main total K: 48–54.
- Ranking: splits, cuts, visual defects, shape, then balance. Any visual-defect override is explicit REVIEW, not an implicit ranking change.
- M1: authoritative polygon/connector gate, full coverage and neck rules; unresolved checks are unknown, not passes. G1 is an approved change whose implementation is still pending; current gate uses shared-border width.
- `tools/looks/score.py` does not implement D3 yet. Cached ELIGIBLE/tier labels are not current eligibility certificates.
- Owner permanently accepted the 58 pre-#128 renders as-is. Do not regenerate them, ask again, or let a blanket deck build refresh them.
- Shapes matter; balanced slivers are not successful territories.
- No sales, shares, rep names, or firm names leave the extract.
- #103/#129/#130 are on hold; their old issue bodies are not execution contracts.

## Starting candidates — cached evidence only

All three have existing summary images. Scouts must revalidate current dollars, M1 evidence, rendering provenance, and ranking before recommending any candidate.

| Shortlist ID and label | Cached standing | Summary image |
|---|---|---|
| `ne_plains_wh11_fi20_whnonj` — NE + plains combined, WH 11 (national 15 / WH 11 / FI 20 / combined 3), smallest-δ plan, WH without NJ split, 12 splits | Tier P rank 1; 12 splits, 20 cuts | `runs/exp/contig/set125/fi20_wh_nonj-r1/summary.png` |
| `ne_plains_wh11_fi20_finotn_whnonj` — NE + plains combined, WH 11 (national 15 / WH 11 / FI 20 / combined 3), smallest-δ plan, FI without TN, WH without NJ, 12 splits | Tier P rank 2; 12 splits, 20 cuts | `runs/exp/contig/set125/fi20_fi_notn_wh_nonj-r1/summary.png` |
| `ne_plains_wh11` — NE + plains combined, WH 11 (national 15 / WH 11 / FI 20 / combined 3), border redraw, 14 splits | Earlier lead; 14 splits, 21 cuts | `runs/exp/contig/border/ne_plains_wh11-r2-all/summary.png` |

Registry: https://github.com/helios1168/td/blob/5620a1fb6ee4322489cc90dcb9dc3ba2d96ca1b7/tools/shortlist/shortlist.json

Research reports the lead has national 13/15 districts in D3 band, WH 10/11, FI 20/20. Its national low-dollar figures differ from earlier lander estimates. These remain reported measurements until traced to the ledger at full precision. Do not conclude K 15 is impossible or change K by default.

## Proposed scout swarm

Eight distinct read-only lanes, fresh context. Owner routing: five `openai-codex/gpt-6.1-sol:high` scouts for history/decisions and the four channel seams; three `claude-bridge/claude-sonnet-5-5:medium` scouts for map inventory, live state and presentation. Sonnet uses the shell-free reader profile. First-pass reports fit the 10-minute intake-and-synthesis target; report evidence and gaps rather than continuing an unbounded search.

| Lane | Sources | Required return |
|---|---|---|
| Map inventory | Shortlist, experiment index, manifests, renders | Main-map candidate inventory; exact run/image paths; versions; missing/stale artifacts and accepted legacy-render exceptions. No history exploration. |
| History and decisions | Project memory, relevant sessions/issues, latest owner rulings | Current contract with exact source anchors; superseded decisions; failed approaches worth avoiding. |
| Live work and compute | Session metadata on both Studios, worktrees, branches, active solver jobs | Ownership/process map; relevant unlanded changes; active versus stale work; shared-resource contention. |
| National | Candidate ledgers/scenarios; planner, draw and repair entry points | Current band risks; smallest plausible repair; dependencies, files, commands and runtime evidence. |
| WH | Same sources, WH-specific history | Same report, prioritizing low-dollar districts without reopening the settled ranking. |
| FI | Current FI drawings and prior shape work | Strongest reusable FI seed; remaining defects; whether FI can remain unchanged. |
| Combined WIFI | Scenario cell partition, combined-state layouts, ledgers | Exact footprints and fine-channel ownership; E3 global dollar-mean band; global coupling and assembly hazards. |
| Presentation pipeline | Renderer, shortlist builder, existing decks | Shortest scoped PDF/PNG assembly path; captions, legends, caveats, provenance and packaging gaps. No refresh of the accepted 58 renders. |

### Common scout packet

- Explicit repo, worktree, pinned refs and source seam.
- Read-only: no edits to project/source files, commits, merges, publication, new jobs, renders, solver/gate runs, nested agents, or unsolicited peer messages.
- Read existing evidence only. Managed output artifacts are allowed; no repo-root scratch reports or new permanent agent/config files.
- Code navigation uses Serena first where available; history uses targeted session search/inspection, not raw transcript dumps.
- Output: evidence anchor and timestamp; candidate ID/run path; verified versus cached/reported/unknown status; proposed next action; expected runtime with evidence; blockers and owner questions.
- End reports with `LEARNED` and `DECIDED` lines.
- Use native supervisor coordination for unresolved consequential choices; do not silently settle scope, bands, solver tolerances, or acceptance.

## Coordination and ownership

- `contiguity` owns main, shortlist registration, issues, STATE.md and problem/watchdog records for this handoff. Send candidate run folder, tier and facts there; do not edit those stores directly.
- `td-research` coordinates shared experimental tool interfaces. Notify it before proposing interface changes.
- Research currently runs six IFA region sessions. Do not duplicate their tasks or alter their worktrees.
- Future runs get unique tracked folders and parent-run provenance; never overwrite existing runs. Use existing run/repair entry points and the tracked renderer.
- One integration/shortlist/deck handoff writer; separate repair writers only with exclusive worktrees and bounded ownership.
- Solver cap is 12 machine-wide, including gate solvers. Research plans 11 IFA slots plus one assembly slot. Owner has allocated none to main work; no solver launch until that changes.

## Deadline plan and hold points

1. After explicit scout-launch approval: target 10 minutes for intake, synthesis and the first candidate comparison.
2. Hold point: return strongest existing candidate(s), current-rule failures, and the smallest proposed repairs. Obtain solver allocation and any required execution approval before repairs.
3. If repairs are authorized: prioritize national/WH deficiencies; preserve FI and combined outputs where sound. No automatic K/layout change, new pipeline, division sealing, or broad architecture work.
4. Reserve the final hour for complete merged-ledger coverage, M1, target-dollar checks, visual review, registration and scoped PDF/PNG assembly. These checks may themselves require allocated solver slots.
5. Freeze outputs with 30 minutes remaining. Record incomplete work and prepare stakeholder talking points rather than starting another solve.

No guaranteed completion claim. If a fully eligible map cannot be achieved, present the strongest registered progress candidates with explicit failures and unanswered questions. Never label a failing map eligible, final, or minimal.

## Presentation package

- Main overview and national/WH/FI/WIFI-or-combined pages for selected registered candidates.
- Small comparison table: channel K, splits/cuts, visual defects, per-district dollar compliance, M1 verdict, provenance and caveats.
- PDF plus PNG images; concise talking points and next-step decision list.
- Labels match registered render titles, including `FAILS M1` where applicable.

## Approval state

- Branch/decision check with both sessions: complete.
- Annotator review: owner changed intake/synthesis target from 30 to 10 minutes; incorporated.
- Worktree setup and read-only scout launch: completed with owner approval.
- Scout wave: `73bad6a7-d6cb-4463-b3e5-946206535a98`; managed reports, no project/source edits.
- Solver allocation: zero for main work.
- Project code execution, tests, gates, repairs, map generation and publication: not authorized.

LEARNED: Current cached shortlist tiers do not establish D3 target-dollar eligibility.
DECIDED: none.
