"""One-off E1/D3/E3 dollar audit. No solver, geography gate, renderer or repo writes."""
import collections
import csv
import datetime
import gzip
import hashlib
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace

WT = Path('/Users/sandvault-ntlee/.pi/worktrees/national-scouts-2026-10-08')
HUB = Path('/Users/Shared/sv-ntlee/td')
PREFIX = Path('/Users/sandvault-ntlee/drafts/td-main-map-dollar-audit-2026-10-08-v2')
sys.path.insert(0, str(WT))
from tools.looks.score import TARGET, dollar_rates, dollars_per_district

CASES = {
    'ne_plains_wh11_fi20_finonc_whnonj': HUB / 'runs/exp/contig/set125/fi20_fi_nonc_wh_nonj-r1',
    'ne_plains_wh11_fi20_whnonj': HUB / 'runs/exp/contig/set125/fi20_wh_nonj-r1',
}


def sha(path):
    with path.open('rb') as fh:
        return hashlib.file_digest(fh, 'sha256').hexdigest()


def status(usd, lower, upper):
    return 'below' if usd < lower else 'above' if usd > upper else 'in'


# Runnable boundary check; no tolerance added to the owner's dollar bands.
assert [status(v, 850e6, 1150e6) for v in (850e6 - 1, 850e6, 1150e6, 1150e6 + 1)] == [
    'below', 'in', 'in', 'above']
assert status(1035e6, 85 * 900e6 / 100, 115 * 900e6 / 100) == 'in'
assert not PREFIX.with_suffix('.json').exists() and not PREFIX.with_suffix('.csv').exists()
source = HUB / 'instance_descaled.json.gz'
source_hash = sha(source)
for folder in CASES.values():
    manifest = json.loads((folder / 'manifest.json').read_text())
    assert manifest['provenance']['instance_sha256'] == source_hash, 'Extract changed since seed run'

with gzip.open(source, 'rt', encoding='utf-8') as fh:
    payload = json.load(fh)
assert payload.get('format') == 'td_instance_descaled/3', 'Unexpected extract format'
# Opportunity allowlist only; no share, share_free or firm data retained or emitted.
nodes = {key: payload['nodes'][key] for key in ('z', 'channel', 'm_rel')}
del payload
assert len(nodes['z']) == len(nodes['channel']) == len(nodes['m_rel'])
assert all(isinstance(m, (float, int)) and math.isfinite(m) and m >= 0 for m in nodes['m_rel'])
assert all(isinstance(z, str) for z in nodes['z'])
source_cells = dict(zip(zip(nodes['z'], nodes['channel']), nodes['m_rel']))
assert len(source_cells) == len(nodes['z']), 'Duplicate source cells'
rates = dollar_rates(SimpleNamespace(channel=nodes['channel'], m_rel=nodes['m_rel']))

report = {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_head': 'f11faed228f4df20afb41421011b164265178e18',
    'policy_commit': '1293d41',
    'rate_helper_sha256': sha(WT / 'tools/looks/score.py'),
    'audit_script_sha256': sha(Path(__file__)),
    'extract_sha256': source_hash,
    'usd_per_m_rel': rates,
    'scope': 'Dollar arithmetic only; no M1, shape, full vertex coverage or eligibility certificate',
    'numerics': 'Existing float E1 helpers; bands 85*target/100 and 115*target/100; unrounded comparisons; no tolerance added',
    'donors': 'Surplus above lower edge is arithmetic capacity, not proof of movable territory',
    'candidates': {},
}
all_rows = []
for candidate, folder in CASES.items():
    # Fingerprint every original run file, including accepted images, before/after the read.
    before = {p.name: sha(p) for p in folder.iterdir() if p.is_file()}
    with (folder / 'ledger.csv').open(newline='') as fh:
        ledger = list(csv.DictReader(fh))
    with (folder / 'districts.csv').open(newline='') as fh:
        declared = {r['district']: r['channel'] for r in csv.DictReader(fh)}
    run = json.loads((folder / 'run.json').read_text())
    by_district = collections.defaultdict(list)
    seen = set()
    for r in ledger:
        key = (r['zip_code'], r['current_channel'])
        assert key not in seen, 'Duplicate ledger cell'
        seen.add(key)
        assert float(r['m_rel']) == source_cells.get(key, 0.0), 'Ledger opportunity differs from source'
        assert not r['rep'], 'Expected district-only ledger'
        assert r['district'] in declared, 'Ledger cell has missing/undeclared owner'
        assert r['model_channel'] == declared[r['district']], 'District channel mismatch'
        assert r['current_channel'] in rates, 'Missing whole-extract rate'
        by_district[r['district']].append(r)
    assert set(by_district) == set(declared), 'Empty or missing district'
    measured = {}
    for channel in sorted(set(declared.values())):
        ids = sorted(d for d, c in declared.items() if c == channel)
        assert len(ids) == run['channels'][channel]['k'], 'K mismatch'
        mean = dollars_per_district(channel, len(ids), ledger, rates)
        target = mean if channel == 'WIFI' else TARGET[channel]
        lower, upper = 85 * target / 100, 115 * target / 100
        values = []
        for district in ids:
            owned = by_district[district]
            usd = dollars_per_district(channel, 1, owned, rates)
            assert math.isfinite(usd) and usd >= 0
            row = {
                'candidate': candidate, 'channel': channel, 'district': district,
                'usd': usd, 'lower_usd': lower, 'upper_usd': upper,
                'status': status(usd, lower, upper),
                'shortfall_usd': max(0.0, lower - usd),
                'surplus_above_floor_usd': max(0.0, usd - lower),
                'states': '+'.join(sorted({r['state'] for r in owned})),
            }
            values.append(row)
            all_rows.append(row)
        measured[channel] = {
            'k': len(ids), 'mean_usd': mean, 'lower_usd': lower, 'upper_usd': upper,
            'min_usd': min(r['usd'] for r in values), 'max_usd': max(r['usd'] for r in values),
            'in_band': sum(r['status'] == 'in' for r in values),
            'below': [r['district'] for r in values if r['status'] == 'below'],
            'above': [r['district'] for r in values if r['status'] == 'above'],
            'total_shortfall_usd': sum(r['shortfall_usd'] for r in values),
            'total_surplus_above_floor_usd': sum(r['surplus_above_floor_usd'] for r in values),
        }
    after = {p.name: sha(p) for p in folder.iterdir() if p.is_file()}
    assert before == after, 'Original run files changed during audit'
    report['candidates'][candidate] = {
        'folder': str(folder), 'input_sha256': before,
        'ledger_rows': len(ledger), 'ledger_zips': len({r['zip_code'] for r in ledger}),
        'checks': 'Unique cells; unchanged opportunity; declared owners/K; originals unchanged',
        'channels': measured,
    }
assert sha(source) == source_hash, 'Extract changed during audit'
with PREFIX.with_suffix('.json').open('x') as fh:
    json.dump(report, fh, indent=2, sort_keys=True)
    fh.write('\n')
with PREFIX.with_suffix('.csv').open('x', newline='') as fh:
    writer = csv.DictWriter(fh, fieldnames=list(all_rows[0]))
    writer.writeheader()
    writer.writerows(all_rows)
for candidate, result in report['candidates'].items():
    print(candidate)
    for channel, s in result['channels'].items():
        print(f"  {channel}: {s['in_band']}/{s['k']} in band; range ${s['min_usd']/1e6:.6f}M–"
              f"${s['max_usd']/1e6:.6f}M; below {s['below']}; above {s['above']}")
    for r in all_rows:
        if r['candidate'] == candidate and r['status'] != 'in':
            print(f"  {r['district']}: ${r['usd']/1e6:.6f}M, shortfall ${r['shortfall_usd']/1e6:.6f}M; {r['states']}")
print('Saved:', PREFIX.with_suffix('.json'), PREFIX.with_suffix('.csv'))
