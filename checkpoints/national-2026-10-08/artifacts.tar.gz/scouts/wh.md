# Code Context

## Files Retrieved
Source inspected at HEAD `f11faed228f4df20afb41421011b164265178e18`; checkout clean. Intake read completely: `/Users/sandvault-ntlee/drafts/td-main-map-scout-intake-2026-10-08.md` (1–80; dated 05:40 CDT).

1. `tools/shortlist/shortlist.json` (12–37, 603–623, 695–715): three candidate IDs, labels, cached ranking.
2. `td/spec.py` (644–669), `td/master.py` (137–166), `tools/exp/contig/wholeplan.py` (88–133): tau-band construction/planning, not fixed-dollar planning.
3. `tools/exp/contig/repair.py` (312–395, 680–738, 1094–1200): window restrictions, trigger logic, units/scoping.
4. `tools/looks/score.py` (263–277, 328–345, 378–387): whole-extract rate helper; stale channel-average dollar eligibility.
5. `docs/lenses/REVIEW_2026-10-07.md` (50–54, 158–180): WH floor, reported $841M, unresolved K question.

Artifact prefix **H** = `/Users/Shared/sv-ntlee/td/runs/exp/contig/`. Saved evidence, not source-HEAD outputs:
- **A** = `set125/fi20_wh_nonj-r1`; `run.json` 1–85, `manifest.json` 1–92, `render.json` 1–42, `districts.csv` 17–27, `contig.json` 137–210, 265–380, 431–440.
- **B** = `set125/fi20_fi_notn_wh_nonj-r1`; corresponding `run.json` 1–85, manifest timestamp/provenance lines 5,76,89, render lines 29–34, district rows 20–27.
- **C** = `border/ne_plains_wh11-r2-all`; `run.json` 1–81, manifest lines 5,29,42, render lines 29–34, district rows 20–27.
- `H/set125/_specs/fi20_wh_nonj.toml` 28–40, 59–69: WH fine=`wh`, K11, NJ excluded from free list; WIFI-labelled bundle combines all five fine channels.
- Visually read all three `H/<A|B|C>/zip_WH.png`; no generation.

## Key Code / Candidate Evidence
**Provisional reusable seed: A**, ID `ne_plains_wh11_fi20_whnonj`, label “WH without NJ split, 12 splits.” B ID `ne_plains_wh11_fi20_finotn_whnonj`, label “FI without TN, WH without NJ, 12 splits.” C ID `ne_plains_wh11`, label “border redraw, 14 splits.” Each has saved `summary.png`, `zip_WH.png`, `zip_pages.pdf` under corresponding directory.

Cached all-map counts: A 12 splits/20 cuts/2 defects; B 12/20/3; C 14/21/4. Saved WH image captions: A/B two split states CA/PA; C three CA/NJ/PA. A/B remove NJ cut; retain broad Midwest shape. B differs near PA, no evident WH advantage sufficient to override A’s cached overall ranking.

All three saved WH captions report minimum **$841M**, mean **$922M**. All three district row 25 records same `WH_09`, support `IN+KY+MI+WI`, drawn mass `672.5551898910002` m_rel. Reading confirms shared light territory; no fresh dollar conversion or 10/11 verification. $850M floor still unmet in saved presentation. Cached M1/coverage passes and ELIGIBLE labels are not current D3 certificates.

Run provenance: A/B commit `bd9c2e0`; finished respectively `2026-10-07T10:40:34Z` / `11:43:45Z`. C commit `848e482`; finished `2026-10-06T01:52:11Z`. Renders: A `2026-10-07T11:16:50Z`, B `12:33:05Z` (both dirty renderer); C `2026-10-06T19:36:15Z` (clean).

## Architecture / Start Here
Open `repair.py:680–738` first: **repair triggers only detached pieces/necks, not low dollars**. Already-connected WH_09 gets no balance repair. `--keep-support` also cannot donate neighboring states into its whole-state support.

`--window LO,HI` means **m_rel**, never dollars; intersects every channel’s existing final band, even with WH-only selection. Freeze full-extract WH rate before conversion; avoid applying WH window to other channels. Scoped planning recomputes tau; smallest delta cannot certify fixed $850M–$1,150M window. Bundle here is combined-channel exemption, not ordinary WIFI’s dollar-mean ±15% rule.

## Smallest Follow-on / Gaps
Proposal only: fixed-K, fixed-footprint whole-state regroup screen around WH_09 and neighboring WH territories; freeze remaining ledger, preserve splits/cuts, then bounded neck-aware realization only if feasible. Existing CLI alone cannot perform dollar-only repair. Partial-state donation would add split unless offset elsewhere; do not promise cap-preserving fix.

Saved timing: A WH PA draw 894.82s (`contig.json:176–210`); 112-ZCTA neck repair 0.2s, unchanged 2 splits/3 cuts (`265–370`). Fast neck repair is **not** evidence fast dollar regroup.

Missing: frozen exact WH rate/state dollars, feasible local regroup, current D3/M1/full-cell audit. Owner question before implementation: authorize bounded fixed-K regroup? If infeasible, broader replan/K reconsideration requires separate approval. No execution now; G1 off; preserve 58 accepted renders, 2025 vintage, masking, coverage, looks-first ranking.

LEARNED: Saved three WH seeds share light WH_09; repair CLI has no dollar-only trigger and --window accepts m_rel globally.
DECIDED: none

```acceptance-report
{
  "criteriaSatisfied": [{"id":"criterion-1","status":"satisfied","evidence":"Read-only WH shortlist, provenance, repair constraints and gaps documented."}],
  "changedFiles": [],
  "testsAddedOrUpdated": [],
  "commandsRun": [{"command":"ls -l candidate WH images; git status --short; git rev-parse HEAD","result":"passed","summary":"Images exist; checkout clean; pinned HEAD confirmed."}],
  "validationOutput": ["No application code, tests, gates or solvers executed."],
  "residualRisks": ["D3 current eligibility unknown; local cap-preserving regroup feasibility unknown."],
  "noStagedFiles": true,
  "diffSummary": "No project changes; managed scout report only.",
  "reviewFindings": ["repair.py:680–738 cannot repair dollar-only violations."],
  "manualNotes": "Saved evidence read; cached/reported values not recomputed. No confidential extract read."
}
```
