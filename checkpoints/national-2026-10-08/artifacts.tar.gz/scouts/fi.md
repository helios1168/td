# Code Context

FI only. Read-only inspection at 2026-10-08 10:45Z. Source HEAD `f11faed228f4df20afb41421011b164265178e18`; checkout clean. `H` = `/Users/Shared/sv-ntlee/td/`; `S` = `H/runs/exp/contig/set125/`. Numbers below **saved/reported**, never fresh measurements.

## Files Retrieved
1. `/Users/sandvault-ntlee/drafts/td-main-map-scout-intake-2026-10-08.md` (complete, lines 1–85): authority, reported FI20/20.
2. `tools/shortlist/shortlist.json` (603–745): six FI20 variants, cached ranks/verdicts/images; (11–37): older lead.
3. `docs/lenses/REVIEW_2026-10-07.md` (31–58, 105–121): D3, cuts-first ranking, FI seed, assembly.
4. `docs/lenses/review-2026-10-07/report3-fable.md` (26–35): reported no-NC FI dollar range, six splits/nine cuts.
5. `docs/memory/decisions/scenario-sweeps-2026-10.md` (13–14); `docs/memory/facts/scenario-sweeps-2026-10.md` (38–42): prior eastern-shape decisions/limitations.
6. `tools/looks/score.py` (87–95, 271–277, 328–345, 419–422): old mean-dollar eligibility; cuts absent from rank key.
7. `td/audit.py` (480–507, 888–889): G1 default off.
8. `S/TABLE.md` (3–13); `S/fi20_{wh_nonj,fi_notn_wh_nonj,fi_nonc_wh_nonj}-r1.check.txt` (each line 1); corresponding `.score.txt` (5–6): cached comparisons/M1/ownership.
9. `S/fi20_fi_nonc_wh_nonj-r1/manifest.json` (1–98), `render.json` (1–50); `.log` (75–81, 474–478): provenance/runtime.
10. `S/_specs/fi20_fi_nonc_wh_nonj.toml` (42–76): FI footprint; five-fine-channel combined bundle.
11. Read saved `zip_FI.png` in three shortlisted variants and `H/runs/exp/contig/border/ne_plains_wh11-r2-all/`.

## Key Code / Evidence
Scorer checks channel-average dollars within ±10% plus mass around τ; **not D3 per-district dollars**. `rank_key` skips cuts. Hence cached P1/P2/P3 order cannot decide settled ranking.

Reported FI20/20 traces to intake peer claim for older `ne_plains_wh11`; saved FI page labels $851M–$1,009M. No fresh direct-dollar certificate found. Stronger explicit tracked reading: Fable report gives no-NC seed $874M–$981M, six splits/nine cuts, rule C satisfied. Those remain reported calculations. Saved images label baseline $880M–$981M, no-TN $871M–$981M, no-NC $874M–$981M; all consistent with FI D3 $765M–$1,035M, not independently verified.

## Architecture / Candidate shortlist
All three: NE + plains **combined**, national15/WH11/FI20/combined3. Display `WIFI` here contains all five fine channels; combined exemption applies, not ordinary WIFI mean-band semantics.

IDs use prefix `ne_plains_wh11_fi20_`; image paths:
- `whnonj`: `S/fi20_wh_nonj-r1/zip_FI.png`; saved whole-map 12 splits/20 cuts/2 defects.
- `finotn_whnonj`: `S/fi20_fi_notn_wh_nonj-r1/zip_FI.png`; 12/20/3.
- **`finonc_whnonj`**: `S/fi20_fi_nonc_wh_nonj-r1/zip_FI.png`; **12/19/4**. Best saved candidate under splits→cuts→defects, despite cached P3. FI alone: six splits, one small TN piece (0.196τ), no thin/crowded defects reported. Baseline/no-TN FI each six splits, zero such FI defects; no-TN alone saves no whole-map cuts.

All three saved M1 checks report zero detached pieces/necks/missing owners/missing fine cells/duplicates. Visual reading: no-NC keeps NC whole, avoids baseline east–west TN strip; PA/OH/VA shapes remain involved. Shape preference not owner acceptance. Older lead FI has seven splits; not ranking winner.

## Start Here / Bounded next step
Open saved no-NC FI image, alongside baseline; reuse FI unchanged for progress review, conditional on unchanged footprint/routing and assembly identity. No FI solve justified now. Original no-NC repair queued 11:33:28Z, finished 11:43:54Z on Oct 7; repeated 120-second unknown windows, final connected incumbent at time limit. Re-solving risks spending budget to recover existing geometry, not proving improvement.

Provenance: repair commit `bd9c2e0…`, dirty; renderer `f9db312…`, dirty, rendered 2026-10-07 12:37:10Z—not scout HEAD. Checks dated Oct 7. G1 stays off; never refresh 58 accepted renders.

Missing: direct D3/rate provenance for each candidate, current gate/hash agreement, complete assembled coverage and national/WH compliance. Existing captions retain obsolete ±10% target wording; disclose separately, no refresh. Global metro carve changes national/WH too; earlier Philadelphia attempt worsened WH and retained PA crowding. Historical “NC required” is restriction-specific, superseded by saved no-NC variant, not universal bound. Owner review: accept no-NC shape or prefer baseline despite extra cut? No K/band decision made.

LEARNED: none
DECIDED: none

```acceptance-report
{
  "criteriaSatisfied": [{"id":"criterion-1","status":"satisfied","evidence":"FI seeds compared with saved image, source, cache and provenance distinctions; bounded reuse proposal and gaps recorded."}],
  "changedFiles": [],
  "testsAddedOrUpdated": [],
  "commandsRun": [{"command":"date; git status/log/diff; ls -lT","result":"passed","summary":"Inspection only; pinned HEAD and clean checkout confirmed."}],
  "validationOutput": ["No application code, tests, gates, rendering or measurements executed."],
  "residualRisks": ["Cached eligibility lacks D3 and cuts-first ranking; artifact producer dirty; assembly and owner shape acceptance unverified."],
  "noStagedFiles": true,
  "diffSummary": "Managed scout report only; no project changes.",
  "reviewFindings": ["No fresh eligibility claim; no-NC ranks ahead on saved cuts, not cached tier order."],
  "manualNotes": "Read intake completely; no confidential extract, history dump or peer messages. LEARNED: none. DECIDED: none."
}
```
