# Code Context

## Files Retrieved
Source: scout HEAD `f11faed228f4df20afb41421011b164265178e18`, commit timestamp 2026-10-08T05:39:55−05:00; clean `git status`. Inspection timestamp 2026-10-08T10:45:33Z. Intake read completely. Below `H` means exact root `/Users/Shared/sv-ntlee/td/`; artifact paths are ignored hub evidence, not scout-HEAD output.

- `td/spec.py` lines 391–443, 646–693: partition, national fallback, global τ, component boundaries.
- `docs/problem/PROBLEM.md` lines 56–63; `docs/problem/MANDATES.md` lines 59–72: ranking, D3/E3, footprint ownership, neck rule.
- `scenarios/51_total_13n_11wh_24fi_3wifi.toml` lines 1–28, 74–84: ordinary eight-state WIFI.
- `tools/looks/score.py` lines 87–95, 263–277, 328–345, 378–387: stale mean-based scorer.
- `tools/shortlist/shortlist.json` lines 12–37, 603–623, 695–715: candidate IDs/images and cached verdicts.
- `H/runs/exp/contig/set125/_specs/fi20_wh_nonj.toml` lines 7–70; sibling `fi20_fi_notn_wh_nonj.toml` lines 9–70; `H/runs/exp/contig/wh_dollar/s13_WH11.toml` lines 3–64: same combined domain/K.
- `H/runs/exp/contig/set125/fi20_wh_nonj-r1/ledger.csv` lines 1–6, `districts.csv` lines 48–50, `contig.json` lines 441–482, `manifest.json` lines 1–95: routing samples, three saved supports, cached connectivity, runtime/provenance.
- `tools/exp/contig/merge.py` lines 8–18: unchanged-cell merge contract.

## Key Code
`check_partition` requires exactly one planning channel per `(unit, fine)`; `check_national` keeps national's three fine channels together, otherwise routes `national_chase`/`wells_fi` with `fi`, `wells_wh` with `wh`. `assemble` computes `tau = sum(M[u] for u in keep) / c.k`, not regional mean.

**Semantic result: all three anchors are combined, despite internal/display `WIFI`.** Saved domain holds all five main fine channels on CT MA ME NH RI VT plus ID MT ND SD WY NE KS OK NM. Saved supports: CT+RI; MA+ME+NH+VT; nine-state plains block. Ledger sample explicitly assigns all five MA cells to `WIFI_03`, including zero-opportunity cells. Combined dollar-band exemption applies; ordinary WIFI E3 does not. This does **not** exempt M1, ownership, looks or total K.

Ordinary legacy WIFI also holds all five fine channels, but eight-state western domain CO ID MT ND NE NM SD WY and fixed blocks distinguish it. Current rule: each ordinary WIFI district within ±15% of **whole WIFI dollar mean**, dependent on K_WIFI. Legacy `delta=1.0` is historical, not current acceptance. No explicit combined/ordinary type marker found; label or presence of five channels alone cannot classify new scenarios.

## Architecture
Whole-extract fine-channel rates → dollar sum of owned cells → channel/district verdict. Never derive rates from regional extracts. National/WH/FI D3 targets fixed; ordinary WIFI mean depends on global domain and K. Moving combined footprint reroutes all five channels, changes other channel totals, feasible K/layout; main total remains 48–54. Existing K 15/11/20/3 is seed metadata, not newly selected policy. Channels factorize only after routing/domain/K fixed. Footprint coverage includes zero-opportunity territory; every cell one owner. Disjoint exact-ZCTA assembly may preserve districts, but cannot silently seal divisions or treat regional gate as national pass.

## Start Here / shortlist
Start saved `fi20_wh_nonj.toml` lines 55–70; semantic seam explicit.

Existing PNG/PDF pairs: each run below contains `summary.png`, `zip_pages.pdf`; combined detail `zip_WIFI.png` exists for first.

1. `ne_plains_wh11_fi20_whnonj` — WH without NJ; `H/runs/exp/contig/set125/fi20_wh_nonj-r1`. Cached 12 splits/20 cuts. Manifest finished 2026-10-07T10:40:34Z, clean producer `bd9c2e0`.
2. `ne_plains_wh11_fi20_finotn_whnonj` — FI without TN, WH without NJ; `H/runs/exp/contig/set125/fi20_fi_notn_wh_nonj-r1`. Cached 12/20. Finished 2026-10-07T11:43:45Z, producer `bd9c2e0`.
3. `ne_plains_wh11` — earlier lead; `H/runs/exp/contig/border/ne_plains_wh11-r2-all`. Cached 14/21. Finished 2026-10-06T01:52:11Z, producer `848e482`.

Smallest proposal: reuse existing combined pages unchanged; visually compare first two seeds before any authorized bounded national/WH dollar repair. Saved combined diagnostics show whole states, no repair/groups, connected status; no new combined solve justified. Repair runtime precedent exists in manifests, not timing promise. Preserve 58 accepted renders; G1 off.

Missing: fresh D3/E3, full ownership/neck recheck, visual review, ledger equality across seeds. Cached ELIGIBLE/M1 not fresh verification. Owner question for future novel carve: ordinary WIFI or exempt combined? Explicit classification needed before applying band.

LEARNED: NE+plains seeds use internal WIFI for exempt combined; ordinary eight-state WIFI shares same five fine channels.
DECIDED: none.

```acceptance-report
{"criteriaSatisfied":[{"id":"criterion-1","status":"satisfied","evidence":"Source/artifact semantics traced; shortlist, provenance, reuse boundary and gaps reported."}],"changedFiles":[],"testsAddedOrUpdated":[],"commandsRun":[{"command":"date; git status --short; git log -1; ls -lT named artifacts","result":"passed","summary":"Inspection only; clean snapshot and saved timestamps observed."}],"validationOutput":["No application code, tests, gates or computations executed."],"residualRisks":["D3 absent from cached scorer; new-scenario semantic classification untyped; full ledger/visual validation not performed."],"noStagedFiles":true,"diffSummary":"Managed scout report only; no project edits.","reviewFindings":["Cached eligibility cannot establish current acceptance."],"manualNotes":"Verified reading distinguished from saved/reported verdicts; confidential extract unopened."}
```
