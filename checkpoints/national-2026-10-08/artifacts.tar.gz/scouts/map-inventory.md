# Main-map artifact inventory (read-only, 2026-10-08)

I read the pinned `tools/shortlist/shortlist.json`, `runs/shortlist/INDEX.md`, and the `render.json`, `manifest.json`, `scorecard.md` and `*.score.txt` files for the anchor runs. I did not run, render or recompute anything, and I did not read the confidential extract. Every number below is cached or reported, not freshly verified.

## Provenance

- **Source:** the pinned `shortlist.json` is HEAD f11faed. Its tier labels (1, P, 3, S, E) are cached shortlist metadata. The INDEX note says "scorer ELIGIBLE", but the scorer does not implement D3, so that flag cannot stand in for a D3 check.
- **Artifacts:** all runs live under the hub `runs/exp/contig/...`. Each run folder contains `summary.png/.svg`, `zip_{national,WH,FI,WIFI}.png`, `zip_pages.pdf`, `render.json`, `manifest.json`, `scorecard.md`, `ledger.csv`, `districts.csv`, `contig.json` and `run.json`. I confirmed this by listing the three Tier-P/lead folders below. I did not list the folders of the other candidates.
- **Render versions:** the renders used different renderer commits, and the shortlist/INDEX show no sign of a post-#128 re-render of any anchor.
  - `ne_plains_wh11-r2-all`: rendered 2026-10-06 19:36Z at commit 9f92395, dirty=false.
  - `fi20_wh_nonj-r1`: rendered 2026-10-07 11:16Z at commit bd9c2e0, dirty=true.
  - `fi20_fi_notn_wh_nonj-r1`: rendered 2026-10-07 12:33Z at commit f9db312, dirty=true.
  - The legacy 58-render exemption is untouched; I recommend no refresh.

## Candidate matrix

All three anchors have the same layout: NE + plains combined, national 15 / WH 11 / FI 20 / WIFI-combined 3, 49 districts. Cached `m1` status is pass in each `render.json`, with the audit passing, 0 pieces and 0 necks.

| Shortlist ID (tier/rank) | Hub run | Image | Cached splits / cuts | Cached $ per district, from score.txt or shortlist notes |
|---|---|---|---|---|
| `ne_plains_wh11_fi20_whnonj` (P/1) | `set125/fi20_wh_nonj-r1` | `summary.png` + `zip_pages.pdf` | 12 / 20; 2 defects; worst 9.3%, mean 4.2% | FI $925M, WH $922M, national $1,126M, WIFI $1,123M |
| `ne_plains_wh11_fi20_finotn_whnonj` (P/2) | `set125/fi20_fi_notn_wh_nonj-r1` | same set | 12 / 20; 3 defects; mean 4.4%; cut border 37,852 km | the same FI/WH/national/WIFI means as whnonj, in `.score.txt` lines 1–3 |
| `ne_plains_wh11_fi20_finonc_whnonj` (P/3) | `set125/fi20_fi_nonc_wh_nonj-r1` | `summary.png` + `zip_pages.pdf` listed in the shortlist; I did not list the folder | 12 splits, 3 small districts | not read |
| `ne_plains_wh11_fi20_mind` (P/4) | `set125/na15_wh11_fi20-r1` | `render.json` found; images per shortlist | 13 / 20; 1 defect; mean 4.2% | national $1,126M (-9.9%), WH $922M (-7.8%), FI $925M (+2.8%) |
| `ne_plains_wh11_fi20_finotn` / `_finonc` (P/5, P/6) | `set125/fi20_fi_notn-r1`, `fi20_fi_nonc-r1` | `summary.png` + `zip_pages.pdf` listed | not read | not read |
| `ne_plains_wh11` (T1/1, the only tier 1) | `border/ne_plains_wh11-r2-all` | `summary.png` + `zip_pages.pdf` | 14 / 21; 3 small districts; mean 5.2% | national mean $1,126M (-9.9%) per the pre-neck note |

- **Pre-D3 means for the lead:** shortlist tier 1 predates D3, which says the national mean sits at the edge.
- **Legacy deck pages for the lead:** `runs/autonomous_2026-10-05/batch_border/deck/1_ne_plains_wh11.png` and `.../zip/1_ne_plains_wh11_zip_pages.pdf`. These are old accepted renders; do not refresh them.
- **Tier P is cached "pending owner review".** The shortlist note says "owner places it".

Other maps found:
- `ne_plains_wh11_fi19` (T3/19) fails M1 with 1 detached piece. Its cached $ per district is FI $974M, WH $922M, national $1,126M.
- Pre-neck and no-combined maps (`nocomb_*`, `low6_cb1*`, `ne_plains_wh12`, `ne_plains_wh11_pre_neck`, the `S`-tier pre-M1 maps) fail M1 or are superseded. They have no seed value for the main review.
- The `ifa_*` entries (tiers 3 and E) are IFA, not national. The Tier-E ones pass M1 and fail only a tier-1 balance check, for which the owner accepted any band on 2026-10-07. They are out of scope for this lane. I did not check the IFA/regional worktrees (ifa-*, research), and I did not look for post-10-07 artifacts there.

## Verified reading versus cached/reported

- **Read from tracked or saved files.** These are cached values only; the tier and eligibility labels are not D3.
  - Folder contents and `render.json` M1 status.
  - Scorecard M1 text: 13 mass necks listed beside M1, diagnostic only (the `fi20_wh_nonj-r1` scorecard and `render.json`).
  - Cached means from `fi20_wh_nonj-r1.score.txt`.
  - Shortlist tier and rank.
- **Reported by peers, with no saved evidence found.** I could not find where the "13/15 national, 10/11 WH, 20/20 FI" D3 compliance numbers (two national districts at about $1,016M and $1,021M, one WH at about $841M) are saved. They are not in the three score files I opened, which carry only channel means and not per-district minima. Treat them as unknown until traced to a saved file.
- **Unknown.** Per-district dollars versus the D3 bands, and the WIFI ±15% mean-dollar band. The $1,123M WIFI figure is a mean from the cached score file; I checked it against no band. The combined channel's exemption is separate, and I could not tell from the saved scorecard how the combined channel is handled. The scorecard names the combined channel "WIFI" and its display name is not proof of bundle semantics. Whether `scenarios/ledger.csv` shows the combined bundle is not checked.

## Smallest next step (propose only)

1. Ask the contiguity lander for a D3-correct per-district dollar read of the three P1–P3 / lead candidates (fine-channel rates, WIFI mean band, combined exempt), using saved `districts.csv` and `ledger.csv`, so the review does not rest on cached tier labels.
2. Show whnonj (P/1) and finotn_whnonj (P/2) at the stakeholder review, and the lead `ne_plains_wh11` as the pre-D3 baseline. Evidence for P/1 and P/2: audit pass, M1 pass, 12 splits, and a render in the stakeholder PDF/PNG format already present in the folder.
3. Do not re-render any of them for this step.

## Gaps and owner questions

- The three images (`summary.png`, `zip_pages.pdf`) are not yet viewed. I did not open them, so I make no visual or shape-quality claim.
- The `fi20_fi_nonc_wh_nonj-r1`, `fi20_fi_notn-r1` and `fi20_fi_nonc-r1` runs were not opened.
- The research worktree's D3 compliance table is unlocated.
- **Owner question:** which of P/1–P/3 to present, and whether a fresh render is needed for the review given the renderer commits above. The standing rule against refreshing old renders applies only to the 58 pre-#128 ones.

LEARNED: none
DECIDED: none