# Live-state coordination map (lane: worktree, session and ownership)

Written 2026-10-08 from the 05:40 CDT intake. No shell was available, so the remote Studio, process arguments and ignored run contents are unread. Nothing was executed, and every dollar and status figure is reported or cached, not re-measured.

## Evidence read (verified reading of tracked text)
- Intake `/Users/sandvault-ntlee/drafts/td-main-map-scout-intake-2026-10-08.md`, 05:40 CDT. It is the only source for the roster, heads and PIDs below.
- `explore-td-research/docs/lenses/IFA_TONIGHT_PLAN_2026-10-08.md` (about 05:00 owner's clock). It names six IFA orchestrators on `m5-studio/ifa-<region>` branches cut from `m5-studio/explore-neck`, with slots 2/1/3/2/1/2 = 11 of 12 and one spare for assembly. The assembly session owns the CONUS merge into `runs/exp/contig/ifa_conus/` and the export, and the lander owns registration. The clock is 06:30 region merges, 07:15 CONUS gate and 07:45 export.
- `explore-td-research/docs/lenses/research-2026-10-08/DECISIONS-2026-10-08.md`, which is newer than the pinned neck copy:
  - F1 (MD stays whole as a one-state waiver) and F2 (IFA K chosen from 46–55) are confirmed.
  - F3 declines the 58-render refresh for good.
  - G1 (neck width across coverage gaps) is a flag, default off.
  - G2 (NY land floor) is applied.
  - The slot cap was raised to 12 at about 04:10.
  - The IFA band verdict is E2 at $1,000M–$1,437.5M, reported per district. The τ ±15% line is information only.
- `explore-td-research/docs/lenses/CHANNEL_COVERAGE_SKETCH_2026-10-08.md` lines 11–36 (a sketch, not a plan):
  - Each state is either pure (national, WH and FI planned separately) or combined (all five fine channels merged into WIFI).
  - WIFI's band is ±15% of the global dollar-weighted mean over all WIFI districts, so it is not fixed.
  - WIFI couples every division that has combined states.
  - This is the ordinary-WIFI mean band. It is distinct from the combined-channel exemption in the intake's D3 note, and the two must not be conflated.
- Other tracked research material on disk: the `ifa-conus` worktree carries `docs/lenses/research-2026-10-08/` (ORACLE-PLAN, ORACLE-TASK, packets P1–P7) and `review-2026-10-07/`. I did not read it.

## Conflict to flag
G3 (owner, about 05:35, research tab) applies `TD_NECK_GAP_WIDTH=1` to the South Central merge and the CONUS IFA merge, and reports both verdicts.
- This is IFA-scoped, so it does not contradict "G1 off for main-map verdicts". It does mean the gate's flag state is a per-run choice. Any main-map evidence must record the flag state.
- Any verdict other than El Paso that the flag flips goes to the owner and is not decided.
- Filing of G1/G3 in PROBLEM.md and MANDATES.md is still the lander's, and #131 is unlanded.

## Ownership map (as of 05:40; later state unknown)
| Owner | Scope | State |
|---|---|---|
| contiguity 01a109e4 | main, shortlist, STATE.md, issues, lander | active |
| contiguity-fast 01a10ae2 | hub cwd | idle, older context |
| td-research 01a119b6 (explore-td-research, 61363df) | shared experimental tools, IFA plan author, assembly | active |
| td-ifa-newengland (01ffe5e), southatl (20cfe36), midwest (8eeb8bf), west (a2d2602), southcentral (a1bfa93) | regional IFA draws and merges | idle at snapshot |
| midatl (ifa-midatl 02fffd5) | Middle Atlantic IFA | no live session in the roster |
| unnamed worker, ifa-conus | CONUS assembly, likely | active in bash; run ID unknown |

- The `ifa-ny` worktree (d3b2b92) is dated Oct 8 and is probably the midatl or NY sub-lane. Its ownership is unknown.
- Idle IFA tabs at 05:40, only 40 minutes after the 05:00 launch, probably mean they are waiting on child workers or solvers. This is not proof they are done or abandoned.
- Other worktrees (geography, hypergraph, neck, nj, nycd, toy, the /tmp whatif_W1/W3, L1–L6) have unknown activity. Do not treat them as reclaimable.
- Four Python PIDs were seen, two of them near 100% CPU. This does not establish solver-slot use. The IFA plan budgets 11 slots, and the owner allocated no main slots ("Scout only for now").

## Shared-tool and duplication hazards
1. `run.py --states`, `repair.py --states --window` and `merge.py` live on the `explore-neck` branch. Every IFA branch was cut from it, so a tool fix in one lane will diverge from the others unless research coordinates it. A main-map follow-on must not edit these in place.
2. The IFA lanes and any main-map follow-on both draw state-scope pieces (NE, NJ, NY, PA, TX, MI). Reusing the `runs/exp/contig/nj/` single-state outputs is cheap. Re-drawing them is duplicated work and uses slots.
3. The `ne_plains_wh11` anchors share the NE layout with the IFA New England and Middle Atlantic lanes. Division-level changes there would invalidate the cached anchors' provenance.
4. All three registration paths (shortlist, T1, INDEX.md, STATE.md) go through the lander. Scouts and IFA tabs must not register.
5. The WIFI global-mean coupling means a combined-state choice in one division shifts every division's WIFI band. Any WIFI-or-combined proposal depends on the other lanes' choices.

## Gaps
- Remote Studio (m2/m5-ts) state is unrefreshed and unknown.
- Which IFA region merges have completed since 05:40 is unknown. Check `runs/exp/index.jsonl` and `runs/shortlist/INDEX.md`, which I did not read.
- The ifa-conus worker's run ID, and whether the assembly has begun, are unknown.
- I did not open the ORACLE and packet files, so I make no claim about their relevance to main channels.
- History tools were not attempted, to avoid the lock.

## Smallest next step (proposal only)
The lowest-risk main-map step needs no new slots: ask the lander (contiguity) to confirm the registered tier and render currency of the three anchor candidates from `runs/shortlist/INDEX.md`. It would also say whether `ne_plains_wh11_fi20_whnonj` has saved D3 evidence for the reported 13/15 national and 10/11 WH. Any solver follow-on, such as repairing the two under-band national districts or the one under-band WH district, needs an owner slot allocation first. The cap of 12 is already fully reserved by research.

## Owner questions
1. Does the owner want any of the 12 slots released to main-map work, or should it stay "scout only" until the 07:15 IFA gate?
2. Should the G3 gap-width flag state be stated on every main-map evidence line, given IFA runs it on?

LEARNED[project]: The IFA plan (05:00) reserves 11 of 12 solver slots across six region tabs plus one assembly slot. The G3 gap-width flag is scoped to IFA merges only. WIFI's ordinary band is a ±15% global mean, which is separate from the combined-channel exemption.
LEARNED: none for global or kb.
DECIDED: Treated the intake roster as the sole source of live state and did not infer remote or post-05:40 status; the alternative of guessing IFA progress from idle labels was rejected because idle does not mean done.