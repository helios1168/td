# Code Context

## Files Retrieved
Source: scout HEAD `f11faed228f4df20afb41421011b164265178e18`; clean checkout observed 2026-10-08 10:45:35Z. Intake read completely. Ignored artifacts below belong hub `/Users/Shared/sv-ntlee/td/`, not source HEAD.

1. `tools/shortlist/shortlist.json:12–37,603–623,695–715` — candidate registry; cached ranks/tiers, not D3 verification.
2. `td/spec.py:645–669`; `td/master.py:131–166` — channel mass, τ and support-band rows.
3. `tools/exp/contig/run.py:162–187`; `tools/exp/contig/repair.py:312–399,680–738,1095–1133` — scope, window solver, repair triggers.
4. `tools/looks/score.py:263–277,328–347` — whole-extract fine-channel rates; eligibility compares channel means, not individual districts.
5. `docs/lenses/REVIEW_2026-10-07.md:158–159`; `docs/lenses/research-2026-10-08/ORACLE-DIVISIONS.md:94–101` — conflicting national estimate; explicit correction of K15-impossibility claim.

Artifact paths below relative hub. Saved national `districts.csv:2–16` read in all three folders; scorecard, manifests, render metadata and national PNGs inspected. No fresh gate/rescore.

## Candidate shortlist
- **`ne_plains_wh11_fi20_whnonj`** — NE + plains combined, WH without NJ; `runs/exp/contig/set125/fi20_wh_nonj-r1/{zip_national.png,summary.png,zip_pages.pdf}`. Strongest bundle seed on cached looks-first rank: 12 splits/20 cuts, 2 defects. National geometry visually close to other two.
- **`ne_plains_wh11_fi20_finotn_whnonj`** — additionally FI without TN; `runs/exp/contig/set125/fi20_fi_notn_wh_nonj-r1/{zip_national.png,summary.png,zip_pages.pdf}`. Same saved national mass/support rows as whnonj; no verified ledger identity. Cached 12/20, 3 defects. National-only tie, not independent balance improvement.
- **`ne_plains_wh11`** — earlier border redraw; `runs/exp/contig/border/ne_plains_wh11-r2-all/{zip_national.png,summary.png,zip_pages.pdf}`. Cached 14/21. Useful baseline; no compelling national shape advantage from saved PNG reading.

Provenance: whnonj `manifest.json:5,72–96` records clean `bd9c2e0`, repair 10:39:51–10:40:34Z Oct 7; `render.json:29–35` render 11:16:50Z, dirty renderer. finotn manifest records repair 11:33:19–11:43:45Z Oct 7; render 12:33:05Z, dirty `f9db312`. Baseline `manifest.json:5,29–52` records clean `848e482`, Oct 6; render 19:36:15Z, clean `9f92395`.

## Key Code / D3 evidence
Baseline `summary.svg:58031` saves national range **$1,016M–$1,229M**, mean **$1,126M**. whnonj `summary.svg:58053` saves **$1,014M–$1,229M**, same mean. These are cached rendered values using channel-total conversion, not fresh per-district fine-rate verification. Intake reports baseline 13/15 compliant, lows ~$1,016M/$1,021M; tracked review instead says ~$1,047M. Conflict unresolved. Saved rows identify light national_01 (AL+FL+GA+MS+SC) and national_09 (FL); exact current dollars unknown.

whnonj `scorecard.md:7–19` saves full ownership, 2025 vintage and M1 passes, but final bands concern m_rel. Existing ELIGIBLE does not establish D3. Scenario `_specs/fi20_wh_nonj.toml:13–25,59–70` confirms national K15, four free states, and WIFI-labelled **combined** five-fine-channel domain; combined exemption applies, not ordinary WIFI mean band.

## Architecture / bounded proposal
`spec.build` sets τ=channel mass/K; master bands center there, not D3 targets. `repair.solve_window` fixes outside ownership and reuses connected/neck-aware, split/cut-capped window machinery. **Repair CLI cannot currently rebalance clean M1 seeds:** `repair_channel` only triggers detached pieces/necks. `--window` intersects m_rel bands; mixed national fine rates prevent treating it as exact dollar adapter.

Smallest plausible follow-on: authorized K15 southeast-only D3 rebalance pilot, outside frozen; first reconcile saved-dollar provenance and test aggregate donor capacity. FL exchange between _01/_09 alone may only move shortage; neighboring _12 and support permissions need inspection. Reuse `solve_window`; prerequisites: full-extract fixed fine rates, individual-dollar rows, explicit balance trigger, approved support/open-unit changes, full ownership/M1 audit. No prescribed K/band change.

Historical runtime, not forecast: whnonj `contig.json:746–930` saves 17-free-ZCTA Texas window 0.1s and 21-free-ZCTA NY window 19.3s. National drawing `:511–556` saves 168.86s connected then 731.13s unknown. Parent draw manifest spans 09:54:15–10:39:50Z. Tiny windows do not promise fast southeast repair.

K15 not ruled out: saved mean lies inside D3; failed drawing proves no global impossibility. K14 comparison remains optional owner-authorized replan, not mandatory conclusion.

## Start Here / gaps
Open `repair.py:312–399,680–738`. Owner question for follow-on authorization: retain K15 local-support pilot first, or permit bounded K comparison? No execution authorized now. Missing: exact fine-rate district dollars, donor-capacity check, repair feasibility, new M1/D3 certification. G1 off; 58 accepted old renders untouched.

LEARNED: Existing repair CLI lacks balance-only trigger; `--window` alone cannot repair D3 deficits in M1-clean seeds.
DECIDED: none

```acceptance-report
{"criteriaSatisfied":[{"id":"criterion-1","status":"satisfied","evidence":"Read-only national seed comparison, exact seams, cached-dollar conflict and residual checks reported."}],"changedFiles":[],"testsAddedOrUpdated":[],"commandsRun":[{"command":"date -u; git status --short; git rev-parse HEAD; ls -lT [named artifacts]","result":"passed","summary":"Inspection only; pinned HEAD and clean checkout observed."}],"validationOutput":["No application code executed; saved evidence only."],"residualRisks":["D3 values conflict; fine-rate compliance and local feasibility unknown."],"noStagedFiles":true,"diffSummary":"Managed report only; no project edits.","reviewFindings":["No fresh acceptance claim; cached eligibility omits D3."],"manualNotes":"National lane only. No extract, tests, solves, rescoring or rendering accessed/executed."}
```
