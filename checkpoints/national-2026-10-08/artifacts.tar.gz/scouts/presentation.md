# Presentation-pipeline scout: progress-review package (read-only; nothing executed)

Source HEAD is f11faed in the scout worktree. Run artifacts are cached at the hub `/Users/Shared/sv-ntlee/td/runs/`. Everything below is a verified reading of source or of a cached file, not a fresh measurement. I could not write the configured output path with these tools, so this response is the artifact.

## Evidence read
- **`tools/shortlist/build.py:171-175`.** `--deck DIR [--tier T] [--jobs N]` is the only deck path. `--registry PATH` takes an alternate registry.
- **`build.py:~118-125` (`render_one`).** For each chosen entry it calls `render.current(run, render_label(e), corridor)`. If that is not current, it shells out to `render.py run --label …`. Titles are `"<id>: <label>"` (`build.py:~58`).
- **`tools/maps/render.py:113-143` (`current`).**
  - A render counts as stale on a changed label, corridor flag, input sha, $-factors file, image sha, or `code_sha256`.
  - `code_sha256` hashes `tools/maps/*.py` and `tools/looks/score.py` (`render.py:~52, 73-85`).
  - A render is stale if either file differs from the cached hash `f71ab5cf…`. I cannot compute the current hash, so "current or stale" is **unknown**.
  - This explains the 58 old renders' "render not current" failures. Any change to `score.py` for D3 would also make every render stale.
- **`render.py:153-200`.** A render deletes `zip_*.png` in the run folder and overwrites `summary.png/svg` and `render.json`. A refresh is destructive to the accepted pages.
- **No-deck mode.** `build.py` without `--deck` renders nothing. It reads `render.json`, rmtree's and recopies `$TD_REPO/runs/shortlist/tier*/`, and rewrites `INDEX.md`. That is a write to ignored hub state, not a refresh of renders.
- **58-render decision.** `docs/lenses/research-2026-10-08/DECISIONS-2026-10-08.md:26-31`: the owner declined F3 for good, and the "render not current" failures are accepted. `ORACLE-PLAN.md:8`: "No 58-map re-render".

## Existing artifacts (cached)
| Artifact | Provenance |
|---|---|
| `runs/shortlist/deck/deck.pdf` and `DECK.md` | 43+ pages in tier and rank order. Built before the #128 renderer change (inferred, not read), so it is not a progress-review artifact. |
| `runs/shortlist/tierP/1_ne_plains_wh11_fi20_whnonj.png` to `6_…finonc.png` | Copies of each run's `summary.png`, made by the no-deck INDEX step. |
| `runs/shortlist/INDEX.md` | Generated view. |
| Each run's `summary.png/svg`, `zip_national/WH/FI/WIFI.png`, `zip_pages.pdf`, `render.json`, `scorecard.md` | Per-run pages. |

## Candidate shortlist (registered IDs and render titles; images are `<run>/summary.png`, with ZIP detail in `<run>/zip_pages.pdf`)
1. **`ne_plains_wh11_fi20_whnonj`**
   - Tier P rank 1, `runs/exp/contig/set125/fi20_wh_nonj-r1`.
   - `render.json` rendered 2026-10-07T11:16:50Z at commit bd9c2e0; M1 recorded as pass.
   - Registry notes: 12 splits, 20 cuts, 2 defects, mean 4.2%, worst 9.3%, cut border 38,992 km.
2. **`ne_plains_wh11_fi20_finotn_whnonj`**
   - Tier P rank 2, `…/fi20_fi_notn_wh_nonj-r1`.
   - Rendered 2026-10-07T12:33:05Z at commit f9db312; M1 pass.
3. **`ne_plains_wh11`**
   - Tier 1 rank 1, `runs/exp/contig/border/ne_plains_wh11-r2-all`.
   - Rendered 2026-10-06T19:36:15Z; M1 pass. It has 14 splits, 21 cuts, and "small" = 3.
   - The registry says "looks scorer ELIGIBLE". That claim predates D3 and is cached.
   - The earlier lead ne_plains_wh11_fi20_mind (13 splits) is a fallback.
   - A fourth P entry, `…_finonc_whnonj`, is also registered. Its metrics were not read.

All three share one `code_sha256` in their `render.json`, so they are renderer-consistent with each other.

## Auto-refresh hazards (do NOT run)
- `build.py --deck <dir>` with no `--tier`, or with tier 1/2/3/E/S, would call `render.py` on every stale entry. That is the blanket 58-map refresh the owner declined.
- `build.py --deck` with `--tier P` is also unsafe if the tier-P renders turn out stale. That depends on the unknown `code_sha256` and on label drift.
- Any `render.py <old run>` without `--if-stale`.
- `--registry` with a three-entry file does **not** make a deck safe, because staleness is judged per entry.

## Shortest scoped package
There is no tracked subset deck builder. The safest package needs no renderer at all:
1. Show the three existing `summary.png` files in the order above, from the run folders directly. Add each run's `zip_pages.pdf` as the appendix, since every page is already a raster.
2. Every page title carries `render_label` (id and label). It has no D3 content.
3. Add one caveat/provenance cover page (the owner's choice of tool; not scaffolded here) with these items:
   - Source HEAD f11faed versus artifact commits and timestamps (the render.json commits above).
   - M1 pass is cached, from the render-time gate.
   - D3 is not implemented in `tools/looks/score.py`, and "ELIGIBLE" in the registry is a pre-D3 cache.
   - The research-reported D3 figures (national 13/15, WH 10/11, FI 20/20) are reported by the research session and unverified here.
   - The ordinary WIFI ±15% dollar-mean band is separate from the combined-channel exemption.
   - G1 is off.
   - The 58 old renders are accepted as-is.
   - K is not chosen here (national 15 / WH 11 / FI 20 / combined 3 is the registered layout).
4. For a PDF, the owner could approve a single concatenation outside the repo (PIL or `img2pdf` over the three PNGs plus cover). That needs a later command approval and would write only to a new folder.
5. Alternative low-risk step: the no-deck `build.py` run, only if the owner accepts it rewriting the ignored `runs/shortlist/tier*` copies and `INDEX.md`. It is not needed for the package.

## Missing checks (not done)
- Whether the three renders are current under the present `tools/maps` and `score.py`. This needs the hash, so it needs execution.
- Which of the three candidates is D3-compliant. The research-reported figures are unverified.
- The `render.json` M1 status for the 4th P entry and for `ne_plains_wh11`'s D3 dollar status.
- Visual inspection of the PNGs. I did not open them.

## Owner questions
None blocking. Two choices are unmade:
- Whether the cover page is acceptable as the vehicle for the D3 and caveat statements.
- Whether the no-deck `INDEX.md` rewrite is acceptable.

LEARNED: build.py --deck re-renders any entry whose render.json code_sha256 (tools/maps/*.py plus tools/looks/score.py) differs, so editing score.py for D3 makes all shortlist renders stale and a blanket --deck would refresh the 58 accepted maps.
LEARNED: none[global]
DECIDED: recommend the existing summary.png and zip_pages.pdf files as the review package, not a --deck build; a --deck build with an alternate registry would still re-render stale entries.