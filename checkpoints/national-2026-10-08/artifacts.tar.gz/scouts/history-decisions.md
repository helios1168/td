# Code Context

History/decision seam only. No ranking, execution or new measurements. Inspected 2026-10-08 05:46 CDT. Source `f11faed228f4df20afb41421011b164265178e18` (05:39:55 CDT); research independently `61363df1cc9538f5b380a203280f303320ddb1b4` (05:36:37 CDT). Both checkouts clean. Reading verified; outcomes reported/cached.

## Files Retrieved
1. `/Users/sandvault-ntlee/drafts/td-main-map-scout-intake-2026-10-08.md` (1–63): complete 05:40 CDT intake.
2. `WATCHDOG.md` (1–137), `docs/problem/PROBLEM.md` (1–66), `docs/problem/MANDATES.md` (1–153): authority.
3. `docs/memory/INDEX.md` (1–45), `docs/memory/decisions/scenario-sweeps-2026-10.md` (1–19), `docs/memory/facts/scenario-sweeps-2026-10.md` (5–43): older sweep limitations.
4. `docs/lenses/REVIEW_2026-10-07.md` (1–181), `docs/lenses/review-2026-10-07/CONSOLIDATED.md` (16–153, targeted hits): held design.
5. `docs/lenses/research-2026-10-08/DECISIONS-2026-10-08.md` (1–30), `README.md` (1–27), `ORACLE-PLAN.md` (1–110), `ORACLE-DIVISIONS.md` (91–132): prior decisions/corrections.
6. `/Users/sandvault-ntlee/.pi/worktrees/explore-td-research/docs/lenses/research-2026-10-08/DECISIONS-2026-10-08.md` (1–78), `IFA_REGION_BOARD.md` (1–33): newer G3/runtime handoff.
7. `tools/looks/score.py` (17–34, 87–96, 328–345, 419–421), `tools/shortlist/shortlist.json` (12–20, 603–624, 695–715): stale code/caches.

## Key Code
`eligibility()` checks τ ±15% and channel-average dollars ±10%; `rank_key()` omits cuts. Both differ from settled policy. Cached ELIGIBLE/tier/rank cannot prove current acceptance.

## Architecture
**Current authority:** PROBLEM:62 supersedes older bands, not ranking. National $1,062.5M–$1,437.5M; WH $850M–$1,150M; FI $765M–$1,035M. Whole-extract fine-channel rates; off-map dollars excluded. Ordinary WIFI: ±15% of global dollar mean; combined exempt. Registry labels say combined, notes say WIFI: inspect scenario/ledger semantics before exemption.

M1 hard: 2025 polygon rook plus approved connectors. Multipart/footprint rulings apply (MANDATES:43–63). Every extract cell owned once; zero-opportunity territory cannot become display fill. Rank splits, cuts, defects, shape, balance. Mass-only slivers/border-length proxy never settle shape acceptance (ORACLE-PLAN:17–21). Restricted bound cannot establish global “minimal” (PROBLEM:61).

**Superseded:** IFA K≥50 revoked; K46–55 remains. MD-only waiver widened to MD+DE+WV (PROBLEM:64); old Oracle notes still say MD alone. Four-process cap superseded by reported owner cap12; 11 IFA slots plus assembly reserved, no main allocation. Older sweep passes used Voronoi/display fill and zeroed FI cell: not current M1/full-ownership evidence.

**G1/G3:** main verdicts keep `TD_NECK_GAP_WIDTH` off until #131 lands. New research G3 (`5a686475`, 05:34:50 CDT) applies prototype to South Central/CONUS IFA, both verdicts reported. Not general main authorization. Owner quote contradicts itself: “necks caused by empty zips should trigger a fail”; research interprets surrounding “pass it”/“GREAT looking map” as coverage-gap acceptance. Board:14 reports G3 PASS; board:20 still says failure. Default gate reportedly fails El Paso. Other flag-flipped verdicts require owner, not inference.

58 old renders permanently accepted unchanged (DECISIONS:27–30). No refresh or renewed consent request.

**Held design:** #103/#129/#130 off ready; v1 invalid. Carve-first supersedes plan/carve/cut/re-plan; unknown never support ban (REVIEW:22–32, 120–122). Live issue bodies not inspected.

**Conflicting dollars:** REVIEW:158–159 reports national low about $1,047M; intake reports $1,016M/$1,021M. Neither freshly verified. “K must be re-chosen” too strong: ORACLE-DIVISIONS:100 rejects national K15 impossibility.

## Start Here
`PROBLEM.md:62–66`, then newer research decisions:69–78. Smallest proposal: reconcile saved decision/gate provenance and label existing images; no launch. Runtime handoff reports unsuccessful 1,800s MI/CA draws (research board:27–32); no basis for promising nationwide rebuild within review window.

References only; labels NE+plains combined, national15/WH11/FI20/combined3:
- `ne_plains_wh11`: border redraw; `runs/exp/contig/border/ne_plains_wh11-r2-all/summary.png`.
- `ne_plains_wh11_fi20_whnonj`: WH without NJ; `runs/exp/contig/set125/fi20_wh_nonj-r1/summary.png`.
- `ne_plains_wh11_fi20_finotn_whnonj`: FI without TN, WH without NJ; `runs/exp/contig/set125/fi20_fi_notn_wh_nonj-r1/summary.png`.
Paths registry-verified; freshness/current eligibility unknown. PDFs registered alongside.

Gaps: session search returned “Session index not ready yet”; no retry. Saved D3 district evidence, current ownership/shape checks, live issues and runtime logs not verified. Owner questions only before later execution: main slots, K/routing changes, G3 flips beyond El Paso. No choice made.

LEARNED: Research G3 narrower than main authorization; retain default main gate.
DECIDED: none.

```acceptance-report
{"criteriaSatisfied":[{"id":"criterion-1","status":"satisfied","evidence":"Read-only reconciliation, exact sources/provenance and gaps above."}],"changedFiles":[],"testsAddedOrUpdated":[],"commandsRun":[{"command":"date; git status --short; git log -1; wc; rg","result":"passed","summary":"Inspection only; source/research provenance and clean checkouts confirmed."}],"validationOutput":["No application code or tests executed."],"residualRisks":["History unavailable; reported gates/dollars unverified; contradictory G3 quote."],"noStagedFiles":true,"diffSummary":"Managed scout artifact only; no project edits.","reviewFindings":["Scorer lacks D3/cuts; IFA G3 cannot transfer to main."],"manualNotes":"Reading verified; cached/reported outcomes distinguished."}
```
